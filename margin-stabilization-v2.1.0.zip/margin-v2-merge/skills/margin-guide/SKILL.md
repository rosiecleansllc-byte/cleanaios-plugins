---
name: margin-guide
description: >
  Use this skill when the user types /margin or asks about their margin
  percentage, labor cost, profitability, or what a good margin looks like
  for a cleaning business. Delivers a conversational, stage-aware explanation
  of their numbers with specific improvement actions.
---

# Margin & Stabilization — Margin Guide Skill

## What This Skill Does
Takes the user's margin percentage (or labor cost %) and delivers:
- A plain-English explanation of what the number means
- A stage-matched benchmark comparison
- A green / yellow / red health rating
- 2–3 specific, actionable next steps to improve

---

## Business Stage Benchmarks

Use these to evaluate the user's numbers. Match their stage by monthly revenue:

| Stage | Monthly Revenue | Healthy Gross Margin | Warning Zone | Danger Zone |
|-------|----------------|---------------------|--------------|-------------|
| 1 — Validation | Under $10k | 45–55% | 35–44% | Under 35% |
| 2 — Stability | $10k–$20k | 48–58% | 38–47% | Under 38% |
| 3 — Systems | $20k–$35k | 50–60% | 40–49% | Under 40% |
| 4 — Leadership | $35k–$50k | 52–62% | 42–51% | Under 42% |
| 5 — Ownership | $50k–$75k | 55–65% | 45–54% | Under 45% |
| 6 — Scale | $75k–$100k | 57–67% | 47–56% | Under 47% |
| 7 — Enterprise | $100k+ | 60–70% | 50–59% | Under 50% |

**Gross margin** = Revenue minus direct labor cost, divided by revenue.
**Healthy labor cost** = 35–45% of revenue for most residential cleaning businesses.
**Overhead** typically runs 15–25%, leaving **net margin of 15–25%** for a well-run operation.

---

## Response Format

Always respond conversationally — never just a table. Structure:

### 1. Name the number
"Your gross margin is X% — here's what that means for a cleaning business at your stage..."

### 2. Rate it
Use one of three ratings with a plain explanation:
- ✅ **Thriving** — above the healthy range for your stage
- 🟡 **Stable but watch it** — in the warning zone, not urgent but needs attention
- 🔴 **Danger zone** — below healthy range, margin is being compressed

### 3. Explain why it matters
Connect it to real business impact — can they hire, can they grow, are they paying themselves, what happens if one client cancels?

### 4. Give 2–3 specific actions
Tailor actions to their stage. Examples by situation:

**If labor % is too high:**
- Review your pay structure — are you paying % of job or flat rate? Flat rate often protects margin better as jobs get faster
- Audit your lowest-margin jobs — one-time cleans under $X are often margin killers; consider raising minimums
- Track job time vs. charge — if a $180 job takes 4 hours with 2 cleaners, you're losing money

**If revenue is too low to support current costs:**
- Raise your recurring rate by $10–$20 per visit — most clients absorb a well-communicated increase
- Focus on biweekly conversions — one-time clients cost more to serve per dollar earned
- Cut one-time jobs from your schedule if they're pulling your margin below 40%

**If overhead is eating margin:**
- Audit your fixed costs — software, supplies, vehicle — and identify anything that can be cut or negotiated
- At Stage 2+, supplies should be 3–5% of revenue; if higher, buy in bulk or raise supply fees

**If margin is healthy:**
- Protect it as you scale — hiring a manager or adding a truck often temporarily compresses margin
- Build a 2–3 month cash reserve before expanding
- Consider raising prices 5–8% annually to stay ahead of labor cost increases

---

## Rules
- Always be specific — no generic advice
- Match the tone to the plugin: clear, professional, no fluff
- If the user hasn't given their stage or revenue, ask one clarifying question before responding
- Never suggest cutting cleaner pay as a first solution — always look at pricing and efficiency first
- If margin is in the danger zone, be direct but not alarming — give them a clear path forward
