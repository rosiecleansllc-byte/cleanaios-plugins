# Plugin Component Map — v2.1.0
## margin-stabilization-plugin.jsx

Last updated: 2026-05-06

---

## Screen Flow

```
MarginPlugin (root)
├── Quick Start Screen  (showQuickStart = true)
│   └── QuickStartScreen
│       ├── Step 01 — Pay Structure (% of job / flat / hourly)
│       ├── Step 02 — Revenue (total, one-time, jobs)
│       ├── Step 03 — Client count + current ACV
│       ├── Step 04 — Frequency (weekly/biweekly/triweekly/monthly) + job hours
│       │             + Real costs (supplies, drive time, insurance, platform fee, cancellation rate)
│       ├── Step 05 — Revenue goal
│       └── Build My Report button
│
└── Tab View  (showQuickStart = false)
    ├── Header (teal border, Cormorant Garamond title, CleanAIOS branding)
    ├── Tab Bar (Price Floor | Revenue Scenarios | Growth Ladder | New Client ACV | Insights)
    ├── Tab: Price Floor — all-in cost breakdown, price floor, leakage detection
    ├── Tab: Revenue Scenarios — 5 scenarios including 90-Day Achievable
    ├── Tab: Growth Ladder — 7 stages (Validation → Enterprise, up to $100K+)
    ├── Tab: New Client ACV — monthly growth number, target ACV, gap analysis
    └── Tab: Insights — AI diagnosis with 5 color-coded sections
```

## Key Variables (v2.1.0)

```
freqDiv          = 4 (weekly) | 2 (biweekly) | 4/3 (~1.33, triweekly) | 1 (monthly)
priceFloor       = (workerPayout + suppliesPerJob + driveTimeCost + insurancePerJob
                   + platformFeePerJob) × cancellationAdj / (1 - targetMargin/100)
newClientRate    = Math.ceil(priceFloor × 1.15 / 5) × 5
monthlyGrowthNum = Math.ceil(gap / currentAcv)
```

## Business Stages (7 total)
Stage 1 — Validation ($0–$10k) | Stage 2 — Stability ($10k–$20k)
Stage 3 — Systems ($20k–$35k) | Stage 4 — Leadership ($35k–$50k)
Stage 5 — Ownership ($50k–$75k) | Stage 6 — Scale ($75k–$100k)
Stage 7 — Enterprise ($100k+)

## Brand Tokens
--teal: #75D3DF | --ink: #111111 | --muted: #555555 | --cream: #F5F5F5 | --border: #E0E0E0
Fonts: Cormorant Garamond (display) | Instrument Sans (UI) | DM Mono (numbers)
