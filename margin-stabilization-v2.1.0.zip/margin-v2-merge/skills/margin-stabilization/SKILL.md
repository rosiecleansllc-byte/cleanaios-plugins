---
name: margin-stabilization
description: >
  Builds and operates the Margin & Stabilization Plugin — a live financial decision
  tool for service business owners (any subcontractor-model business: cleaning,
  landscaping, home services, staffing, etc.) to calculate price floors, detect
  margin leakage, model revenue scenarios, plan new client pricing, and track business
  stage. Use this skill whenever someone asks about pricing a job, checking margin,
  calculating ACV, modeling revenue goals, figuring out if they are charging enough,
  understanding why they are not profitable, or planning how many new clients to add.
  Also trigger for: "am I undercharging", "what should I charge", "show me my margin",
  "how many clients do I need", "is my pricing sustainable", "open the margin plugin",
  "build my report", "run my numbers", "what ACV do I need". Fire broadly — any
  financial modeling, pricing, revenue, or margin discussion for a service business.
commands:
  run-margin-report:
    description: >
      Run a complete margin and stabilization analysis. Renders the interactive
      dashboard and walks through a 5-step intake: pay structure, revenue, client
      count, job details + real costs (with triweekly option), and revenue goal.
      Delivers price floor, leakage, scenarios, growth ladder, and AI diagnosis.
  update-numbers:
    description: >
      Update business numbers and rerun the margin analysis with fresh data.
      Use when revenue, client count, pricing, pay structure, or job mix has changed.
  margin:
    description: >
      Explain what a margin percentage means, rate it against stage benchmarks
      (green/yellow/red), and give 2-3 specific improvement actions.
---

# Margin & Stabilization Skill — v2.1.0

A financial decision tool for service business owners using a subcontractor labor model.
Works for any business where you pay workers per job and charge clients a recurring fee.

Clean architecture: all calculations run through a single math engine before any output
is delivered. No scope issues, no derived values scattered across sections.

---

## Core Math Engine

All calculations derived from these inputs. Everything else is computed — never manually entered.

### Inputs

| Input | Type | Source |
|---|---|---|
| payType | "percent" / "flat" / "hourly" | Quick Start Step 01 |
| laborPct | number | Step 01 (if percent) |
| flatPay | number | Step 01 (if flat) |
| hourlyRate + jobHours | numbers | Step 01 (if hourly) |
| totalRevenue | number | Step 02 |
| oneTimeRevenue | number | Step 02 |
| totalJobs | number | Step 02 |
| recurringJobsCount | number | Step 02 (optional) |
| clientCount | number | Step 03 |
| freqType | "weekly" / "biweekly" / "triweekly" / "monthly" | Step 04 |
| jobHours | number | Step 04 (or Step 01 if hourly) |
| suppliesPerJob | number | Step 04 (optional, default $10) |
| driveTimeCost | number | Step 04 (optional, default $8) |
| insurancePerJob | number | Step 04 (optional, default $6) |
| platformFeePct | number | Step 04 (optional, default 0%) |
| cancellationRate | number | Step 04 (optional, default 5%) |
| targetMargin | number | Auto-derived from laborPct |
| targetAcv | number | Step 05 (optional, auto-calculated) |
| goalRevenue | number | Step 05 |

### Key Derived Values

```
freqDiv         = 4 (weekly) | 2 (biweekly) | 4/3 (~1.33, triweekly) | 1 (monthly)
recRevenue      = totalRevenue - oneTimeRevenue
recJobs         = recurringJobsCount > 0 ? recurringJobsCount : totalJobs
otJobs          = totalJobs - recJobs
recAvgCharge    = recRevenue / recJobs
otAvgCharge     = oneTimeRevenue / otJobs
workerPayout    = laborPct/100 * recAvgCharge  (or flatPay, or hourlyRate*jobHours)
effectiveLaborPct = workerPayout / recAvgCharge * 100
grossMargin     = 100 - effectiveLaborPct
targetMargin    = 100 - laborPct  (auto-set from pay structure)

-- Real Cost Per Job (All-In) --
overheadPerJob  = suppliesPerJob + driveTimeCost + insurancePerJob
platformFeePerJob = recAvgCharge * (platformFeePct / 100)
cancellationAdj = 1 / (1 - cancellationRate/100)  [only if cancellationRate > 0]
totalCostPerJob = (workerPayout + overheadPerJob + platformFeePerJob) * cancellationAdj

priceFloor      = totalCostPerJob / (1 - targetMargin/100)
hourlyFloor     = (totalCostPerJob / jobHours) / (1 - targetMargin/100)
leakagePerJob   = recAvgCharge - priceFloor  (positive = above floor, negative = below)
leakagePerClient = leakagePerJob * freqDiv
totalLeakage    = leakagePerClient * clientCount

currentAcv      = recRevenue / clientCount
currentMrr      = currentAcv * clientCount
stage           = getStage(totalRevenue)  — uses total revenue, NOT just MRR
gap             = goalRevenue - currentMrr

-- New Client Rate --
recommendedNewClientRate = CEIL(priceFloor * 1.15 / 5) * 5
  [price floor + 15% margin buffer, rounded up to nearest $5]

-- Growth Numbers --
monthlyGrowthNumber = CEIL(gap / currentAcv)
  [new clients needed per month to close the gap to goal]
newClients90        = 5 * 3 = 15
  [conservative: 5 new clients/month × 3 months]
projected90Rev      = (clientCount + 15) * currentAcv
pct90               = projected90Rev / goalRevenue * 100

acvNeeded       = goalRevenue / clientCount
legacyRevenue   = currentAcv * clientCount
needFromNew     = goalRevenue - legacyRevenue
```

### Price Floor Formula (All-In)

```
Total Cost Per Job = (Worker Payout + Supplies + Drive Time + Insurance + Platform Fee) × Cancellation Adj
Price Floor = Total Cost Per Job / (1 - Target Margin)
```

Example: ($80 payout + $10 supplies + $8 drive + $6 insurance) × 1.053 (5% cancellation) = $109.52 total cost
Price Floor at 50% margin: $109.52 / 0.50 = **$219 minimum charge**
Recommended New Client Rate: $219 × 1.15 = $251.85 → rounded up to **$255**

### Biweekly ACV Math — Explain This Clearly Every Time

When freqType is biweekly (the most common frequency):
- A client paying $X per visit comes **twice per month**
- Monthly value per client = $X × 2
- Annual value per client = $X × 2 × 12 = $X × 24

Example: $200/visit biweekly client
- Monthly ACV: $200 × 2 = $400/month
- Annual ACV: $400 × 12 = **$4,800/year**

Always say: "Losing one biweekly client at $200/visit doesn't cost you $200 — it costs you **$4,800 a year**."
Always show the leverage: "Raising price by $20/visit on a biweekly client = $40 more/month = **$480 more/year per client**."
With 40 clients: a $20 raise = $1,600 more/month = **$19,200 more/year** — no new clients, no extra work.

### Revenue Scenarios (5 scenarios)

| Scenario | ACV | Description |
|---|---|---|
| Stay Mid-Market | currentAcv | No change — baseline |
| Controlled Test | currentAcv × 1.35 | RECOMMENDED — test 35% higher |
| Stabilized Model | currentAcv × 1.60 | 60% higher, premium model |
| Premium | targetAcv (or acvNeeded) | Full goal ACV |
| 90-Day Achievable | currentAcv + 15 new clients | Conservative capacity plan |

```
clientsNeeded = CEIL(goalRevenue / scenarioAcv)
newClients    = MAX(clientsNeeded - clientCount, 0)
projected     = (clientCount + newClients) * scenarioAcv
```

90-Day Achievable scenario:
- Adds 5 new clients/month × 3 months = 15 new clients at current pricing
- Revenue = (clientCount + 15) × currentAcv
- Shows what % of goal is achievable with realistic growth at current rates

### New Client ACV Table

Legacy clients stay at currentAcv. Only new clients are repriced.

```
legacyRevenue  = currentAcv * clientCount  (locked, unchanged)
needFromNew    = goalRevenue - legacyRevenue
acvForN        = needFromNew / N  (where N = number of new clients to add)
pricePerJob    = acvForN / freqDiv
hitsGoal       = (legacyRevenue + N * acvForN) >= goalRevenue
```

Table rows for: 5, 10, 15, 20, 25, 30, 40, 50 new clients.
Each row shows ACV needed, price per job, and whether it hits the goal.

Always call out commercial/property management as the path to higher ACV:
> "The bigger the ACV per client, the fewer new clients you need. Commercial clients
> (offices, retail, property managers) often pay $400–$800+ per job. Working with even
> one property management company could replace 10–15 residential clients."

### Business Stage Ladder (7 Stages)

Stages based on TOTAL revenue (including one-time), not just MRR:

| Stage | Name | Revenue Range | Top Focus |
|---|---|---|---|
| 1 | Validation | Under $10K | Price at floor or above — build recurring base |
| 2 | Stability | $10K–$20K | Document + delegate — stop doing everything yourself |
| 3 | Systems | $20K–$35K | Route optimization, raise prices 5–8%, build manager layer |
| 4 | Leadership | $35K–$50K | Tiered pricing, retention systems, develop team leads |
| 5 | Ownership | $50K–$75K | Target 55–65% gross margin, systems run without you |
| 6 | Scale | $75K–$100K | Multiple revenue streams, brand authority, operational infrastructure |
| 7 | Enterprise | $100K+ | Think in ACV + lifetime value — this is a portfolio, not a job |

Stage Warnings:
- Stage 1: Underpricing to get clients — getting stuck at cheap rates forever
- Stage 2: Owner doing everything — burnout before systems exist
- Stage 3: Growing revenue but shrinking margin — costs not controlled
- Stage 4: Complacency — pricing hasn't kept up with cost of running the business
- Stage 5: Scaling without margin discipline — high revenue, low profit
- Stage 6: Premature expansion — adding locations before the model is locked
- Stage 7: Owner dependency at scale — business value tied to one person

Revenue Phase Ladder (12 phases):
- Phase 1:  $10K — Break $10K
- Phase 2:  $15K — Confirm Premium Works
- Phase 3:  $20K — Scale Intelligently
- Phase 4:  $25K — Market Dominance
- Phase 5:  $30K — Operational Strength
- Phase 6:  $35K — Systems Running
- Phase 7:  $40K — Owner Optional
- Phase 8:  $50K — Full Ownership
- Phase 9:  $60K — Multi-Crew Operation
- Phase 10: $75K — Regional Presence
- Phase 11: $85K — Scalable Infrastructure
- Phase 12: $100K — Enterprise Ready

---

## Activation — Display Interactive Dashboard

When this skill activates:

**Step 1 — Say this greeting exactly:**
"**Welcome to the Margin & Stabilization Plugin** 💰 I'll build your complete financial picture in about 2 minutes — price floor, margin health, revenue scenarios, and a personalized action plan. Fill out the form below and hit **Build My Report** when you're ready."

**Step 2 — Output the dashboard as a React artifact:**
Read the file at `${CLAUDE_PLUGIN_ROOT}/margin-stabilization-plugin.jsx` and output its
entire contents as a `application/vnd.ant.react` artifact. Do NOT rewrite, rebuild,
or modify the code. Do NOT write any files to disk. Read the file exactly as-is and
output it as an artifact so it renders inline.

Do not ask questions. Do not add any text after the artifact. The form inside the
dashboard handles all input collection.

**Only fall back to the conversational flow below if reading the JSX file fails.**

---

## Quick Start — Conversational Fallback

Only use this if the JSX cannot be rendered. Collect all inputs one step at a time.

### Step 01 — Pay Structure

Three options. All derive an effective per-job payout.

| Pay Type | What to enter | Payout derived as |
|---|---|---|
| % of job (default) | Labor % | laborPct / 100 × recAvgCharge |
| Flat / job | Dollar amount | entered value |
| Per hour | Rate + hours | hourlyRate × jobHours |

Confirm: "So your worker earns about $X per job — does that sound right?"

### Step 02 — Revenue

- Total revenue last month
- Total jobs completed
- How much was one-time? (deep cleans, move-outs, first-time visits)
- If one-time > 0: How many of those jobs were recurring?

Confirm: "So your recurring revenue is $X across Y jobs — averaging $Z per recurring job."

### Step 03 — Clients

- Recurring client count (active, paying, not leads)
- Derive: Current ACV = recRevenue / clientCount
- Derive: Current MRR = currentAcv × clientCount

Say: "Your current ACV is $X/month per client — that's $Y/year. Every client you keep is worth that much."

### Step 04 — Job Details + Real Costs

**Cleaning frequency** — how often do most clients book?

| Frequency | Visits/Month | Notes |
|---|---|---|
| Weekly | 4 | Commercial, premium residential |
| Bi-weekly | 2 | Most common — default assumption |
| Triweekly | ~1.33 | Every 3 weeks |
| Monthly | 1 | Flag for conversion opportunity |

**Average job duration in hours** (e.g. 3 hours — skip if hourly pay already captured)

**Real cost per job** — enter your numbers or use defaults:

| Cost Item | Field | Default |
|---|---|---|
| Supplies per job ($) | e.g. 12 | $10 |
| Drive time cost per job ($) | e.g. 8 | $8 |
| Insurance / overhead per job ($) | e.g. 6 | $6 |
| Platform fee (%) | e.g. 3 | 0% |
| Cancellation rate (%) | e.g. 5 | 5% |

### Step 05 — Goal

- Monthly revenue goal (be honest — this is just math)
- Derive: ACV needed = goalRevenue / clientCount
- Derive: Gap = goalRevenue - currentMrr
- Optional: Target ACV (auto-calculated if blank)

---

## Analysis Sections (Delivered After Quick Start)

### Section 1: Price Floor + Real Cost Breakdown

Always show the full all-in cost breakdown:

| Cost | Amount |
|---|---|
| Worker Payout | $X |
| Supplies | $X |
| Drive Time | $X |
| Insurance/Overhead | $X |
| Platform Fee | $X |
| Subtotal | $X |
| × Cancellation Adj | × 1.0X |
| **Total Cost Per Job** | **$X** |

Then show:
- Price Floor: $X (this is the absolute minimum — never go below)
- Blended Hourly Floor: $X/hr (at their job duration ±30 min)
- Leakage per job: $X (positive = margin buffer, negative = you're losing money)
- Leakage per client/month: $X
- Total monthly leakage across all clients: $X
- **Recommended New Client Rate: $X** (floor + 15% buffer, rounded to $5)

If below floor: "You are charging **below** your all-in cost floor. You are losing money on every job. This is not a cash flow problem — it is a pricing problem."

### Section 2: Premium Pricing Model (ACV Deep Dive)

Always show biweekly math step-by-step:
- Per visit: $X
- Per month (×2): $X
- Per year (×24): $X

Show current vs target ACV side by side.
Calculate what a $20, $30, $50 raise per visit does to annual revenue across all clients.

Revenue source ideas for growing ACV (always mention these):
1. **Commercial clients** — offices, retail, medical waiting rooms. Higher per-job rates, larger spaces, more reliable scheduling.
2. **Property management partnerships** — apartment complexes, short-term rentals, Airbnb operators. Turnover cleans at premium rates.
3. **Short-term rental (STR) operators** — same-day turns, urgent cleans, higher rates justified by time pressure.
4. **Move-out/move-in cleans** — one-time at premium (often $300–$600+). High ACV one-timers that sometimes convert to recurring.
5. **Add-on services** — inside fridge, inside oven, window washing, laundry folding. Add $30–$80 per visit to ACV without adding clients.

### Section 3: Revenue Scenarios

Show all 5 scenarios clearly. For each:
- ACV used
- Clients needed
- New clients to add  
- Projected monthly revenue
- % of goal achieved
- Whether it's realistic (call out any scenario that requires 50%+ price increase as "aggressive")

Highlight 90-Day Achievable every time:
> "Without raising a single price — just adding 5 new clients per month for 3 months —
> you could reach $[projected90Rev]/month. That's [pct90]% of your $[goalRevenue] goal at current pricing."

Always follow with annual impact. "That's $[projected90Rev × 12]/year."

### Section 4: New Client ACV Strategy

Show the full table (5–50 new clients).
Lock legacy clients: "Your [clientCount] current clients stay exactly where they are — $[currentAcv]/month each."
Only new clients are repriced.

Call out commercial opportunity:
> "If even 5–10 of those new clients are commercial or through a property manager, you may
> hit your ACV target without changing residential pricing at all."

### Section 5: Growth Ladder

- Name and describe their current stage
- Top 3 priorities for their exact stage (stage-specific, not generic)
- Gap to next stage: "$X to go. At your current MRR growth rate, that's X months."
- **Monthly Growth Number: "To close your $[gap] gap at $[currentAcv]/month ACV, you need [monthlyGrowthNumber] new clients/month."**
- One warning specific to their stage

### Section 6: AI Diagnosis

Five diagnostic sections. Be direct — this is coaching, not complimenting.

**[DIAGNOSIS]** — What's actually wrong. Name the specific problem (underpriced floor, leakage, wrong frequency mix, too many monthly clients, one-time revenue not being leveraged, stalled stage, etc.)

**[ROOT CAUSE]** — Why it's happening. Not symptoms — the structural cause.

**[RECOMMENDED PATH]** — 3 specific actions in priority order. Stage-specific. No generic advice.

**[THIS WEEK]** — One action before the next call. Concrete, measurable, no excuses.

**[PRICING READINESS]** — Score 1–10. Current margin vs target margin. Above or below floor. One-line verdict: "Ready to raise prices" or "Fix the floor first."

---

## Frequency Reference

| Frequency | Visits/Month | Monthly ACV Math | Note |
|---|---|---|---|
| Weekly | 4 | price × 4 | Commercial, premium residential |
| Biweekly | 2 | price × 2 | Most common — default assumption |
| Triweekly | ~1.33 | price × 4/3 | Every 3 weeks |
| Monthly | 1 | price × 1 | Lowest value — flag for conversion |

Always flag monthly clients: "Every monthly client you convert to biweekly at the same price is worth double the annual revenue — no new acquisition cost."

---

## Rules

- Always show both monthly AND annual impact — annual numbers land harder
- If hiring is involved, always include the margin reality check
- When raising prices, acknowledge 5–10% churn is normal — net gain is still worth it
- Never just give numbers — always explain what they mean in plain English
- If they want to hit a revenue goal, work backwards to show exactly what's required
- Stage 1–2 advice is different from Stage 5–7 advice — always be stage-specific
- 3 priorities max per stage — don't overwhelm
- Frame growth in margin terms, not just revenue — more revenue with worse margin is not progress
- Always use real cost-per-job math when calculating price floor (not just labor)

---

## Trigger Phrases

- "Open my Margin & Stabilization plugin"
- "Check if my pricing is sustainable"
- "What's my price floor?"
- "Model my revenue scenarios"
- "What ACV do I need to hit my goal?"
- "What should I charge new clients?"
- "Am I ready to scale?"
- "How many clients do I need?"
- "Run my numbers" / "Build my report"
- "What's my monthly growth number?"
- "What can I achieve in 90 days?"
- "What's a good margin for my stage?"
- "Am I undercharging?"
- "What's my real cost per job?"
- "What are my costs eating?"

---

## Cross-Doc Dependencies

| File | Relationship |
|---|---|
| AI Agent Operating SOP | Owner-layer financial tool |
| RC Operating System v2 | Margin thresholds link to daily ops decisions |
| RosieSells SKILL.md | ACV targets overlap with quoting logic |
| Lead to Client SOP | Price floor affects quote delivery step |

---

Last updated: 2026-05-06
Changes: v2.1.0 — Added triweekly frequency (4/3×/month), 7 business stages up to $100K+,
real cost per job inputs (supplies/drive/insurance/platform fee/cancellation rate),
all-in price floor formula, Recommended New Client Rate (floor × 1.15 rounded to $5),
5th scenario: 90-Day Achievable, Monthly Growth Number, biweekly ACV explanation with
leverage math, commercial/property management revenue source ideas, extended phase ladder
to 12 phases ($10K–$100K), stage-specific warnings, frequency conversion flag for monthly clients.
