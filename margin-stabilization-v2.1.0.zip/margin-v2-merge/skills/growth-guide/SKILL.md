---
name: growth-guide
description: >
  Use this skill when the user types /growth or asks about their business
  stage, what to focus on, how to get to the next level, or feels stuck.
  Diagnoses their stage and gives a clear, stage-specific action plan.
commands:
  growth:
    description: >
      Diagnose business stage by monthly revenue (7 stages from Validation to
      Enterprise), explain what it means, give the top 3 priorities, and show
      the fastest path to the next stage.
---

# Growth Stage Diagnosis Skill

## What This Skill Does
Identifies the user's business stage by monthly revenue, explains what that stage means, and gives the top 3 priorities for that exact stage — not generic advice.

---

## The 7 Stages

### Stage 1 — Validation (Under $10k/month)
**What it means:** You're proving the model works. Every client matters. Margin can be thin because volume is low.
**The danger:** Underpricing to get clients, then getting stuck there.
**Top 3 priorities:**
1. Price at your floor or above — never discount to fill the schedule
2. Build your recurring base — one-time cleans don't compound
3. Get your first 5-star reviews and start asking for referrals

### Stage 2 — Stability ($10k–$20k/month)
**What it means:** You have a real business. The question is whether it runs without you being on every job.
**The danger:** Owner is doing everything — cleaning, scheduling, quoting, following up. Burnout is real.
**Top 3 priorities:**
1. Document your cleaning process so a second team can replicate it
2. Audit your lowest-margin clients — raise or replace them
3. Build a 60-day cash reserve before adding overhead

### Stage 3 — Systems ($20k–$35k/month)
**What it means:** You're managing teams, not mops. Margin should be improving as volume scales.
**The danger:** Growing revenue but shrinking margin because costs aren't controlled.
**Top 3 priorities:**
1. Implement route optimization — wasted drive time is a margin killer
2. Raise prices 5–8% across the board — most clients at this stage are underpriced
3. Build a manager layer so you can work ON the business

### Stage 4 — Leadership ($35k–$50k/month)
**What it means:** You have a real operation. The business can run without you daily.
**The danger:** Complacency — margin stays flat because pricing hasn't kept up with costs.
**Top 3 priorities:**
1. Implement tiered pricing — premium clients, add-on services, priority scheduling
2. Build retention systems — a client who stays 3 years is worth 3× a new client
3. Develop your next manager or team lead from within

### Stage 5 — Ownership ($50k–$75k/month)
**What it means:** You own a business, not a job. Focus shifts to profitability and exit value.
**The danger:** Scaling without margin discipline — high revenue, low profit.
**Top 3 priorities:**
1. Target 55–65% gross margin — if you're below, something is structurally wrong
2. Build systems that don't depend on any one person
3. Think in annual ACV and client lifetime value, not per-job

### Stage 6 — Scale ($75k–$100k/month)
**What it means:** You have multiple crews, real infrastructure, and a brand people recognize. The business is no longer about you — it's about the system.
**The danger:** Premature expansion — adding new locations or services before the core model is locked. Margin compression from complexity.
**Top 3 priorities:**
1. Build multiple revenue streams — commercial contracts, property management partnerships, premium residential tiers
2. Invest in operational infrastructure — scheduling software, QA processes, team leads at every level
3. Protect margin ruthlessly — at this scale, 1% margin loss = thousands of dollars monthly

### Stage 7 — Enterprise ($100k+/month)
**What it means:** You run a portfolio, not a job. Your focus is on business value, scalability, and long-term wealth — not individual clients or jobs.
**The danger:** Owner dependency at scale — if the business can't run without you for a month, it's not enterprise-level yet.
**Top 3 priorities:**
1. Think in lifetime client value and ACV — every decision should optimize for retention and margin, not volume
2. Build a leadership team that can hire, manage, and improve without you
3. Explore exit value — document systems, financials, and processes as if you're preparing to sell

---

## Response Format

1. **Name the stage** — "Based on $X/month, you're in Stage Y — [Stage Name]"
2. **Describe what that means** — in plain English, what does this stage feel like and what are the risks
3. **Give the top 3 priorities** — specific to their stage, not generic
4. **Show the gap to the next stage** — how far, and what's the fastest path
5. **One warning** — what most owners get wrong at this stage

---

## Rules
- Be specific — Stage 2 advice is different from Stage 4 advice
- Don't overwhelm — 3 priorities max
- If they say they feel stuck, acknowledge it and diagnose why before prescribing
- Always frame growth in terms of margin, not just revenue — more revenue with less margin is not progress
