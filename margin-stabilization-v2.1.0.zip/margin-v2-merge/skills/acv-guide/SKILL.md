---
name: acv-guide
description: >
  Use this skill when the user types /acv or asks about annual client value,
  monthly client value, what a client is worth, or how per-job price connects
  to monthly and annual revenue. Explains ACV with clear math and benchmarks.
---

# ACV — Annual Client Value Skill

## What This Skill Does
Explains what ACV is, calculates the user's current ACV, benchmarks it against healthy targets, and explains the math connecting per-job price → monthly value → annual value.

---

## The ACV Math — Explain This Simply

**Step 1: Per-job price × visits per month = Monthly Client Value**

| Frequency | Visits/Month | $180/job | $200/job | $240/job |
|-----------|-------------|----------|----------|----------|
| Weekly | 4 | $720/mo | $800/mo | $960/mo |
| Biweekly | 2 | $360/mo | $400/mo | $480/mo |
| Triweekly | ~1.33 | $240/mo | $267/mo | $320/mo |
| Monthly | 1 | $180/mo | $200/mo | $240/mo |

**Step 2: Monthly Client Value × 12 = ACV**
- $200 biweekly job → $400/month → **$4,800 ACV**
- $220 biweekly job → $440/month → **$5,280 ACV**
- $180 monthly job → $180/month → **$2,160 ACV**

**Step 3: Current ACV for the business**
> Current ACV = (Total Recurring Monthly Revenue ÷ Number of Clients) × 12

Example: $12,000 recurring MRR ÷ 40 clients = $300/client/month × 12 = **$3,600 average ACV**

---

## Plain English Explanation for Clients

"ACV is how much one client is worth to your business over a full year. A biweekly client at $200/visit pays you $400/month — that's $4,800 a year just from that one person. When you think about it that way, losing one client doesn't just cost you $200 — it costs you $4,800."

"This is why raising your price by $20/visit on a biweekly client isn't just $20 more — it's $40/month or $480/year per client. Across 40 clients that's $19,200 more per year."

---

## Healthy ACV Benchmarks by Stage

| Stage | Monthly Revenue | Healthy Monthly ACV | Healthy Annual ACV |
|-------|----------------|--------------------|--------------------|
| 1 — Validation | Under $10k | $250–$350/mo | $3,000–$4,200 |
| 2 — Stability | $10k–$20k | $300–$400/mo | $3,600–$4,800 |
| 3 — Systems | $20k–$35k | $350–$450/mo | $4,200–$5,400 |
| 4 — Leadership | $35k–$50k | $380–$500/mo | $4,560–$6,000 |
| 5 — Ownership | $50k–$75k | $400–$550/mo | $4,800–$6,600 |
| 6 — Scale | $75k–$100k | $500–$650/mo | $6,000–$7,800 |
| 7 — Enterprise | $100k+ | $600–$800/mo | $7,200–$9,600 |

---

## Response Format

1. **Calculate their ACV** — show the per-job → monthly → annual math
2. **Benchmark it** — compare to their stage target
3. **Rate it** — ✅ healthy / 🟡 low / 🔴 significantly under target
4. **Explain the leverage** — show what a $20 price increase does to annual revenue across all clients
5. **Give one action** — convert monthly clients to biweekly, raise rate by $X, add premium tier

---

## Rules
- Always show the per-job → monthly → annual chain clearly
- Emphasize the multiplier effect — small per-job changes = big annual impact
- If they're confused about biweekly vs monthly, explain it with a simple example
- If ACV is low, the answer is almost always: raise price OR convert frequency, not add more clients
