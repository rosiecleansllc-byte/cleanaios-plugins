---
name: pricefloor-guide
description: >
  Use this skill when the user types /pricefloor or asks about minimum
  pricing, price floors, cost per job, or whether their prices are too low.
  Calculates the minimum charge per job and explains it in plain English.
commands:
  pricefloor:
    description: >
      Calculate the minimum price per job given labor cost and target margin.
      Explains the math, shows what happens below the floor, and compares
      to current pricing.
---

# Price Floor Guide Skill

## What This Skill Does
Calculates the minimum price per job the owner should charge to cover costs and hit their margin target. Explains the math simply and flags if current pricing is below the floor.

---

## The Math

**Price Floor Formula:**
> Price Floor = Worker Payout ÷ (1 − Target Margin %)

**Examples:**
- Worker paid $70/job, owner wants 50% margin → $70 ÷ 0.50 = **$140 minimum**
- Worker paid $80/job, owner wants 45% margin → $80 ÷ 0.55 = **$145 minimum**
- Hourly: cleaner at $18/hr × 3 hours = $54 labor + $20 overhead = $74 total cost → $74 ÷ 0.50 = **$148 minimum**

**What "price floor" means in plain English:**
"This is the lowest price you can charge and still keep enough to pay yourself, cover overhead, and grow. Anything below this number means you're losing money on the job even if it doesn't feel like it."

---

## Cost Components to Identify

If the user doesn't know their costs, walk them through these:

1. **Worker payout** — what you pay the cleaner per job (flat, % of job, or hourly × hours)
2. **Supplies** — roughly $5–$15/job for residential
3. **Overhead per job** — vehicle, insurance, software divided by jobs per month
4. **Owner time** — scheduling, communication, QC (often ignored but real)

**Typical total cost breakdown for a $200 recurring job:**
- Labor: $70–$90 (35–45%)
- Supplies: $8–$12 (4–6%)
- Overhead: $20–$30 (10–15%)
- **Total cost: $100–$132**
- **Margin: 34–50%**

---

## Response Format

1. **Calculate the floor** — show the math clearly
2. **Compare to current pricing** — are they above or below?
3. **Rate it** — ✅ safe / 🟡 thin / 🔴 below floor
4. **Explain the risk** — what happens if they stay below the floor (can't hire, can't grow, paying themselves last)
5. **Give one action** — raise price by $X, adjust pay structure, or add a supply fee

---

## Rules
- Always show the math — don't just give the number
- Never suggest cutting cleaner pay as the first solution
- If they're below the floor, be direct but give a path forward
- If they don't know their costs, ask 2 targeted questions before calculating
