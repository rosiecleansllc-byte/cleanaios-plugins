---
name: scenario-guide
description: >
  Use this skill when the user types /scenario or asks "what if" questions
  about pricing changes, adding clients, changing frequency, or hiring.
  Runs the scenario math and explains the revenue and margin impact clearly.
---

# Revenue Scenario Planner Skill

## What This Skill Does
Takes a "what if" question and calculates the before/after impact on revenue, margin, and profitability — with plain-English explanation of what the numbers mean.

---

## Common Scenario Formulas

### Scenario: Raising prices
**Formula:** (New Price − Old Price) × Jobs/Month × 12 = Annual Revenue Gain
**Example:** Raising from $180 to $200 on 60 biweekly clients
- Gain per client/month: $40
- Total gain/month: $40 × 60 = $2,400
- Annual gain: $2,400 × 12 = **$28,800/year**
- Margin impact: revenue goes up, labor cost stays the same → margin improves

### Scenario: Adding clients
**Formula:** New Clients × Monthly ACV = Monthly Revenue Gain
**Example:** Adding 10 biweekly clients at $200/visit
- Monthly ACV: $200 × 2 = $400/client
- Monthly gain: $400 × 10 = $4,000
- But: if this requires hiring, add labor cost — margin may compress short-term

### Scenario: Converting monthly to biweekly
**Formula:** (Biweekly Monthly Value − Monthly Monthly Value) × Clients Converted
**Example:** Converting 8 monthly clients ($200/visit) to biweekly
- Monthly gain per client: ($200 × 2) − ($200 × 1) = $200 more/month
- Total monthly gain: $200 × 8 = $1,600
- Annual gain: $1,600 × 12 = **$19,200/year** with no new clients

### Scenario: Hiring a new cleaner
**Formula:** New Revenue Possible − New Labor Cost = Net Margin Impact
**Example:** Hiring at $18/hr, 6 jobs/day, 5 days = 30 jobs/week
- New revenue capacity: 30 jobs × $200 = $6,000/week = $24,000/month
- New labor cost: $18 × 6hrs × 30 jobs = $3,240/month
- Gross margin on new capacity: ($24,000 − $3,240) ÷ $24,000 = **86.5%** (before overhead)
- Reality check: add supplies ($300), overhead ($600) → net margin ~83%

### Scenario: Revenue target reverse calculation
**Formula:** Target Revenue ÷ Monthly ACV per Client = Clients Needed
**Example:** Want $25k/month, current ACV is $400/month per client
- Clients needed: $25,000 ÷ $400 = **63 clients**
- Currently have 45 → need 18 more

---

## Response Format

1. **Restate the scenario** — confirm you understood what they're asking
2. **Show the before** — current revenue, margin, or client count
3. **Show the after** — what changes with the new scenario
4. **Calculate the difference** — monthly and annual impact
5. **Flag any risks** — margin compression, capacity limits, client pushback on price increases
6. **Give a recommendation** — is this scenario worth pursuing?

---

## Rules
- Always show both monthly AND annual impact — annual numbers land harder
- If hiring is involved, always include the margin reality check
- If raising prices, acknowledge that some clients may leave — factor in realistic churn (5–10%)
- Never just give numbers — always explain what they mean in plain English
- If they want to hit a revenue goal, work backwards to show exactly what's required
