---
description: Run a revenue scenario — what happens if you raise prices, add clients, or change your frequency mix? Type /scenario with your what-if question and Claude walks you through the numbers conversationally.
---

# Revenue Scenario Planner

Before you make a pricing or growth decision, run the numbers. This command walks you through "what if" scenarios in plain English — no spreadsheet needed.

**You can ask things like:**
- `/scenario what if I raise my biweekly rate from $180 to $200?`
- `/scenario what if I add 10 more recurring clients at $220/visit?`
- `/scenario I want to hit $25k/month — how many clients do I need?`
- `/scenario what if I convert 5 monthly clients to biweekly?`
- `/scenario what happens to my margin if I hire another cleaner at $18/hr?`

Claude will show you the before/after, explain the margin impact, and flag any risks.

**Your scenario:**
