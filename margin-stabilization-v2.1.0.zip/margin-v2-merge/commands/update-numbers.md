---
name: update-numbers
description: >
  Update business numbers and rerun the margin analysis with fresh data. Use when
  revenue, client count, pricing, pay structure, or job mix has changed. Faster
  than starting from scratch — just share what changed.
skill: margin-stabilization
---

The user wants to update their numbers and get a refreshed margin analysis.

Ask them what has changed. They may update one or several inputs:
- Pay structure or labor percentage
- Last month's total revenue
- One-time vs recurring revenue split
- Total jobs or recurring jobs count
- Recurring client count
- Revenue goal or target ACV
- Job frequency or average job hours

Accept whatever they share, confirm the updated values back to them, then rerun
the full analysis using the margin-stabilization skill with the updated numbers.

Key derived values to recalculate whenever inputs change:
- Recurring avg charge = recurring revenue / recurring jobs
- Worker payout = labor% * recurring avg charge (or flat/hourly equivalent)
- Target margin = 100 - labor%
- Price floor = payout / (1 - targetMargin)
- Current ACV = recurring revenue / client count
- New client ACV needed = (goal - legacyRevenue) / number of new clients

If they haven't run a report before in this session, ask them to share all inputs
so you can build their complete picture using /margin-stabilization:run-margin-report.
