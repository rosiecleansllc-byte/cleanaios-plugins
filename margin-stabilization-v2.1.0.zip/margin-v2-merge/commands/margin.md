---
description: Explains what your margin percentage means, whether it's healthy for your stage, and exactly what to do to improve it. Type /margin followed by your current margin % — or just type /margin and Claude will walk you through it.
---

# Margin Guide

Type your current gross margin percentage (or describe your situation) and Claude will:

1. Tell you exactly what that number means in plain English
2. Compare it to the healthy benchmark for your business stage
3. Flag whether you're in the danger zone, stable, or thriving
4. Give you 2–3 specific actions to improve your margin right now

**Example:** `/margin 38%` or `/margin my labor is eating 55% of revenue`

Paste your number or situation below:
