---
description: Explains what ACV (Annual Client Value) means, calculates yours, and tells you what a healthy ACV target looks like for your business size. Type /acv with your numbers or just type /acv and Claude will walk you through it.
---

# ACV — Annual Client Value Guide

ACV is one of the most important numbers in your cleaning business and most owners don't know it.

Tell Claude your situation and get:
1. Your current ACV in plain English
2. What a healthy ACV target looks like for your stage
3. The exact math — how your per-job price connects to monthly and annual value
4. What to do if your ACV is too low

**You can say things like:**
- `/acv I charge $200 biweekly, 45 clients`
- `/acv what should my ACV be at $15k/month revenue?`
- `/acv help me understand what ACV means`

**Your numbers:**
