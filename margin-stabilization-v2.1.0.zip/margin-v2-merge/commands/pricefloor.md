---
description: Calculates the minimum price you should charge per job so you never lose money. Type /pricefloor with your labor cost and target margin and Claude will give you your floor number with a plain-English explanation.
---

# Price Floor Calculator

Tell Claude your numbers and get the minimum price you should charge per job — with a clear explanation of why.

**You can say things like:**
- `/pricefloor my cleaner makes $65 per job and I want a 50% margin`
- `/pricefloor I pay hourly at $18/hr, jobs take 3 hours, overhead is $20/job`
- `/pricefloor I don't know my costs, help me figure it out`

Claude will calculate your floor, explain what happens if you go below it, and tell you where your current pricing stands.

**Your numbers:**
