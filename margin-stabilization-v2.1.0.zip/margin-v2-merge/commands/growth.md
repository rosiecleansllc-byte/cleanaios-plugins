---
description: Diagnoses what business stage you're in, what that means, and the top 3 things to focus on right now. Type /growth with your monthly revenue and Claude gives you a stage assessment with a clear action plan.
---

# Growth Stage Diagnosis

Every cleaning business moves through 5 stages. Knowing yours tells you exactly where to focus — and what to stop wasting time on.

Tell Claude your monthly revenue and get:
1. Your current stage (1–5) with a plain-English description
2. What the numbers say about your business health
3. The top 3 priorities for your exact stage
4. What the next stage looks like and how to get there

**The 5 stages:**
- Stage 1 — Validation (under $10k/mo)
- Stage 2 — Stability ($10k–$20k/mo)
- Stage 3 — Systems ($20k–$35k/mo)
- Stage 4 — Leadership ($35k–$50k/mo)
- Stage 5 — Ownership ($50k+/mo)

**You can say things like:**
- `/growth my revenue is $14,000/month`
- `/growth I'm at Stage 2 but I feel stuck`
- `/growth what should I focus on to get to $20k?`

**Your numbers:**
