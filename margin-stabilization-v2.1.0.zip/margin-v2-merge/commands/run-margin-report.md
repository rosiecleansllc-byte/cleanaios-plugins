---
name: run-margin-report
description: >
  Run a complete margin and stabilization analysis for a service business. Walks
  through a conversational intake of 8 inputs, then delivers a full financial report:
  price floor, leakage detection, revenue scenarios, new client ACV strategy, business
  stage, and an AI diagnosis. Use this to start a fresh margin analysis.
skill: margin-stabilization
---

Start a Margin & Stabilization analysis for this service business.

Tell the user you'll ask a few quick questions to build their complete financial
picture. It takes about 2 minutes. If they already have numbers ready, ask them
to share all at once.

Collect inputs conversationally — one step at a time, not as a form:

Step 1 — Pay structure: How do they pay their worker? Three options: a percentage
of each job (most common), a flat dollar amount per job, or an hourly rate.
If percent: what % goes to the worker?
If flat: how much per job?
If hourly: what rate, and what's the average job length in hours?

Step 2 — Revenue: What was last month's total revenue, and how many jobs were
completed? Then ask: how much of that revenue came from one-time jobs like deep
cleans, move-outs, or first-time visits? If they had one-time jobs, ask how many
of the total were recurring jobs. Derive recurring avg charge and confirm it back.

Step 3 — Clients: How many recurring clients do they have (active and paying,
not one-timers or leads)? Derive current ACV = recurring revenue / client count.

Step 4 — Job details: How often do most clients book? Options: weekly (4×/month),
bi-weekly (2×/month), triweekly (every 3 weeks, ~1.3×/month), or monthly (1×/month).
What's the average job duration in hours? (Skip duration if hourly pay — already
captured in Step 1.)

Optional — Real costs per job (tell them: "If you know these, great — if not, we'll
use typical defaults"): supplies per job (default $10), drive time cost (default $8),
insurance/overhead per job (default $6), platform fee % if using booking software
(default 0%), and cancellation rate % (default 5%).

Step 5 — Goal: What is their monthly revenue goal? Tell them to be honest — this
is just math. Derive target ACV = goal / client count. Ask if they have a specific
target ACV in mind, or if the auto-calculated number works.

Once all inputs are collected, run the full analysis using the margin-stabilization
skill and present the complete report covering: All-In Price Floor + Real Cost
Breakdown, Recommended New Client Rate, Revenue Scenarios (including 90-Day
Achievable), New Client ACV Strategy, Business Stage + Monthly Growth Number,
Phase Ladder, and AI Diagnosis with specific action plan.
